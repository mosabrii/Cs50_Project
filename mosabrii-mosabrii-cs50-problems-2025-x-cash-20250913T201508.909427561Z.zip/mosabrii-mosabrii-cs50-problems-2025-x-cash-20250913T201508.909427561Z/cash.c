#include <stdio.h>
#include <cs50.h>

int main (void)
{
int x;
do
{
    x = get_int ("change owed: ");
}
while (x < 1);

int c = 0;
c += x / 25;
x %= 25;

c += x / 10;
x %= 10;

c += x / 5;
x %= 5;

c += x;

{
    printf ("%i\n", c);
}



}
