#include <cs50.h>
#include <stdio.h>

int main(void)
{
    int x;
    do
    {
        x = get_int("x: ");
    }
    while (x < 1 || x > 8);

    for (int i = 1; i <= x; i++)
    {

        for (int m = 0; m < x - i; m++)
        {
            printf(" ");
        }

        for (int j = 0; j < i; j++)
        {
            printf("#");
        }

        printf("  ");

        for (int q = 0; q < i; q++)
        {
            printf("#");
        }
        printf("\n");
    }
}
